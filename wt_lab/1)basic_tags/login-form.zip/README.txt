A Pen created at CodePen.io. You can find this one at http://codepen.io/SirWags/pen/Jqnxf.

 Simple flat login form.